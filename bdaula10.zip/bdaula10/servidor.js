let colors = require("colors");
let http = require("http");
let express = require("express");
let bodyParser = require("body-parser");

let mongodb = require("mongodb")

let app = express();
app.use(express.static("./public"));
app.use(bodyParser.urlencoded({extended: false }));
app.use(bodyParser.json());

const MongoClient = mongodb.MongoClient
const uri = 'mongodb://localhost:27017';
const client = new MongoClient(uri, {useNewUrlParser: true })

let dbo = client.db("exemplo_bd");
let usuarios = dbo.collection("usuarios")

let server = http.createServer(app);
server.listen(3000);

console.log("Servidor rodando...". rainbow);

////

app.post("/cadastrar_usuario", function(req, resp) {
    var data = {  
        db_email: req.body.email, 
        db_senha: req.body.senha 
    };

    usuarios.insertOne(data, function (err) {
      if (err) {
        console.log(err);
        resp.render('resposta_usuario.ejs', {resposta: "Erro ao cadastrar usuário!"})
      }else {
        resp.render('resposta_usuario.ejs', {resposta: "Usuário cadastrado com sucesso!"})        
      };
    });
  });
